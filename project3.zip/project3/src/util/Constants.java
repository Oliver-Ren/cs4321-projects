package util;

public class Constants {

	public static final int ATTRSZ = 4;
	public static final int PAGESZ = 4096;
	
}
