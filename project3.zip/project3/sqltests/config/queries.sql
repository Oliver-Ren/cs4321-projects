SELECT * FROM Boats B1, Boats B2, Boats B3 where 1 = 1; 
