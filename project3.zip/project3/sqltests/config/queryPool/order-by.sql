select * from Sailors order by Sailors.B;
select * from Sailors order by Sailors.B, Sailors.C;
select A from Sailors order by B;
select * from Reserves, Sailors order by Sailors.B, Reserves.G;
