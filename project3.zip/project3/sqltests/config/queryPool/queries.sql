SELECT * FROM Reserves, Boats;
SELECT * FROM Boats, Sailors;
SELECT * FROM Boats, Sailors, Reserves;
