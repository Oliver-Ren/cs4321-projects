SELECT * FROM Reserves WHERE Reserves.G > 1;
SELECT * FROM Sailors where Sailors.A < 4 and Sailors.B >= 102;
SELECT * FROM Boats where Boats.E = 3 and 1 < 0;
SELECT * FROM Boats where 2 > Boats.E and 1 > 0;
SELECT * FROM Sailors where 4 > Sailors.A and 102 <= Sailors.B;
