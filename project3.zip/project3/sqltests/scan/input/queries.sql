SELECT * FROM Boats;
SELECT * FROM Sailors;
SELECT * FROM Reserves;
