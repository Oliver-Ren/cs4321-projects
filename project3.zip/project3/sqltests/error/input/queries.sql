SELECT TestTable2.M, TestTable2.L FROM TestTable2 ORDER BY TestTable2.L;
