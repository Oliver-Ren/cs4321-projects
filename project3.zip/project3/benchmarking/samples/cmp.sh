diff <(sort expected_humanreadable/query8_humanreadable) <(sort output_humanreadable/query8_humanreadable)
