SELECT * FROM Boats WHERE Boats.E < 10; 
SELECT  * FROM Boats WHERE Boats.E < 500;
SELECT * FROM Sailors WHERE Sailors.A  > 10 and Sailors.A <20;