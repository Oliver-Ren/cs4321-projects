package btree;

import java.util.ArrayList;
import java.util.List;

public abstract class TreeNode {
	
	int order;
	
	public TreeNode(int order){
		this.order = order;		
	}
	abstract public int getMin();
}
