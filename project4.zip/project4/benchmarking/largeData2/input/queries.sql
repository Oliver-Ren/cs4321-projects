SELECT * FROM Boats WHERE Boats.E < 100;   
SELECT  * FROM Boats WHERE Boats.E < 750;  
SELECT * FROM Sailors WHERE Sailors.A  > 100 and Sailors.A <150;  