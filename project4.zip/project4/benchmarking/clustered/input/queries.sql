SELECT * FROM Boats WHERE Boats.E < 10;   
SELECT  * FROM Boats WHERE Boats.E < 300;  
SELECT * FROM Sailors WHERE Sailors.A  > 100 and Sailors.A <150;  