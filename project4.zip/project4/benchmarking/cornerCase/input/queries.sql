SELECT * FROM Boats WHERE Boats.E < 100 AND Boats.E <80;   
SELECT  * FROM Boats WHERE Boats.E > 400 AND Boats.E <> 500;  
