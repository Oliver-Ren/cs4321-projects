SELECT * FROM Boats;
SELECT * FROM Sailors;
SELECT * FROM Reserves;
SELECT * FROM Boats WHERE Boats.D = 101;
SELECT * FROM Boats WHERE Boats.E < 3;

