SELECT * FROM Reserves, Boats;
SELECT * FROM Boats, Sailors;
SELECT * FROM Boats, Sailors, Reserves;
SELECT * FROM Boats B1, Boats B2;
SELECT * FROM Reserves R1, Boats B1, Reserves R2, Sailors WHERE 1 = 1;
SELECT * FROM Sailors S1, Sailors S2, Sailors S3, Sailors S4, Reserves R1, Reserves R2 where 3 <> 4 and 2 = 2;
